set PYTHONPATH=E:\MyDocuments\perfboot\python-packages
python perfboot.py --iterations=2 --interval=30 -v --output=yamcha_boot.tsv